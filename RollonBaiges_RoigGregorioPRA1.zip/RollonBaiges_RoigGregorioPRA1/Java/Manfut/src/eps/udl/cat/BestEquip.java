package eps.udl.cat;

public class BestEquip {
    IdEquip		Equip;
    int		Puntuacio;
    int		IdEmisor;
}
